-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mar 17 Mai 2016 à 20:38
-- Version du serveur :  10.1.13-MariaDB
-- Version de PHP :  7.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `formation`
--

-- --------------------------------------------------------

--
-- Structure de la table `city`
--

CREATE TABLE `city` (
  `cit_id` int(10) UNSIGNED NOT NULL,
  `cou_id` int(10) UNSIGNED NOT NULL,
  `cit_name` varchar(128) DEFAULT NULL,
  `cit_inserted` datetime DEFAULT NULL,
  `cit_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `country`
--

CREATE TABLE `country` (
  `cou_id` int(10) UNSIGNED NOT NULL,
  `cou_name` varchar(80) DEFAULT NULL,
  `cou_inserted` datetime DEFAULT NULL,
  `cou_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `instructor`
--

CREATE TABLE `instructor` (
  `ins_id` int(11) NOT NULL,
  `ins_name` varchar(40) NOT NULL,
  `ins_fristname` varchar(40) NOT NULL,
  `ins_subject` varchar(40) NOT NULL,
  `ins_inserted` datetime NOT NULL,
  `ins_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `marital_status`
--

CREATE TABLE `marital_status` (
  `mar_id` int(10) UNSIGNED NOT NULL,
  `mar_name` varchar(20) DEFAULT NULL,
  `mar_inserted` datetime DEFAULT NULL,
  `mar_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `session`
--

CREATE TABLE `session` (
  `ses_id` int(10) UNSIGNED NOT NULL,
  `tra_id` int(10) UNSIGNED NOT NULL,
  `ses_opening` date DEFAULT NULL,
  `ses_ending` date DEFAULT NULL,
  `ses_nb_students` tinyint(3) UNSIGNED DEFAULT NULL,
  `ses_nb_trainers` tinyint(3) UNSIGNED DEFAULT NULL,
  `ses_inserted` datetime DEFAULT NULL,
  `ses_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `session`
--

INSERT INTO `session` (`ses_id`, `tra_id`, `ses_opening`, `ses_ending`, `ses_nb_students`, `ses_nb_trainers`, `ses_inserted`, `ses_updated`) VALUES
(2, 0, '2016-04-04', '2016-07-29', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `student`
--

CREATE TABLE `student` (
  `stu_id` int(10) UNSIGNED NOT NULL,
  `mar_id` int(10) UNSIGNED NOT NULL,
  `cit_id` int(10) UNSIGNED NOT NULL,
  `cou_id` int(10) UNSIGNED NOT NULL,
  `ses_id` int(10) UNSIGNED NOT NULL,
  `stu_name` varchar(80) DEFAULT NULL,
  `stu_firstname` varchar(40) DEFAULT NULL,
  `stu_birthdate` date DEFAULT NULL,
  `stu_email` varchar(255) DEFAULT NULL,
  `stu_sex` char(1) DEFAULT NULL,
  `stu_with_experience` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `stu_is_leader` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `stu_inserted` datetime DEFAULT NULL,
  `stu_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `student`
--

INSERT INTO `student` (`stu_id`, `mar_id`, `cit_id`, `cou_id`, `ses_id`, `stu_name`, `stu_firstname`, `stu_birthdate`, `stu_email`, `stu_sex`, `stu_with_experience`, `stu_is_leader`, `stu_inserted`, `stu_updated`) VALUES
(90, 0, 0, 0, 2, 'RAIMUNDO', 'Claudio', '1975-01-23', 'claudio@toto.fr', 'M', 0, 0, NULL, NULL),
(100, 0, 0, 0, 2, 'DESWARTE', 'fabrice', '0000-00-00', 'fab@toto.fr', 'M', 0, 0, NULL, NULL),
(104, 0, 0, 0, 2, 'REUTER', 'Marc', '1980-02-08', 'marc@reuters.com', 'M', 0, 0, NULL, NULL),
(108, 0, 0, 0, 2, 'TASCH', 'Philippe', '2015-04-01', 'fifi@toto.fr', 'M', 0, 0, NULL, NULL),
(112, 0, 0, 0, 2, 'CAVRO', 'Michel', '2010-01-01', 'michel.cavro@toto.fr', 'M', 0, 1, NULL, NULL),
(113, 0, 0, 0, 2, 'BARDHI', 'Florian', '1988-02-02', 'flo@toto.fr', 'M', 0, 0, NULL, NULL),
(114, 0, 0, 0, 2, 'CARNEIRO', 'Adelino', '1975-10-01', 'adelino@toto.fr', 'M', 0, 0, NULL, NULL),
(115, 0, 0, 0, 2, 'COELHO', 'Patrick', '1980-03-01', 'pat@toto.fr', 'M', 0, 0, NULL, NULL),
(116, 0, 0, 0, 2, 'FABRI', 'Paul', '2001-02-05', 'polof@toto.fr', 'M', 1, 0, NULL, NULL),
(117, 0, 0, 0, 2, 'IOANID', 'Paul', '1968-02-08', 'poloi@toto.fr', 'M', 0, 0, NULL, NULL),
(118, 0, 0, 0, 2, 'LABIDI', 'Mondher', '1980-12-04', 'apolearn@labidi.lu', 'M', 0, 0, NULL, NULL),
(119, 0, 0, 0, 2, 'ROLLAND', 'Marie', '1980-07-22', 'marie.rolland@toto.fr', 'F', 0, 0, NULL, NULL),
(120, 0, 0, 0, 2, 'SAMPAIO', 'Gabriela', '1980-08-09', 'gabriela@toto.fr', 'F', 0, 0, NULL, NULL),
(121, 0, 0, 0, 2, 'SCHMUTZ', 'Anne', '1976-05-08', 'anne.truc@toto.fr', 'F', 1, 0, NULL, NULL),
(122, 0, 0, 0, 2, 'THIELLO', 'Ibrahima', '1984-06-05', 'ibrahima@toto.fr', 'M', 0, 0, NULL, NULL),
(123, 0, 0, 0, 2, 'VICENTE', 'Demetrio', '1974-05-06', 'demetrio@toto.fr', 'M', 1, 0, NULL, NULL),
(124, 0, 0, 0, 2, 'WAGEMANS', 'Charlotte', '1984-09-07', 'chacha@toto.fr', 'F', 0, 0, NULL, NULL),
(125, 0, 0, 0, 2, 'YIM', 'Anne-Marie', '1980-06-08', 'annemarie@toto.fr', 'F', 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `subject`
--

CREATE TABLE `subject` (
  `sub_id` int(10) UNSIGNED NOT NULL,
  `sub_name` varchar(64) DEFAULT NULL,
  `sub_duration` tinyint(3) UNSIGNED DEFAULT NULL,
  `sub_inserted` datetime DEFAULT NULL,
  `sub_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `training`
--

CREATE TABLE `training` (
  `tra_id` int(10) UNSIGNED NOT NULL,
  `tra_name` varchar(128) DEFAULT NULL,
  `tra_location` varchar(128) DEFAULT NULL,
  `tra_room` varchar(32) DEFAULT NULL,
  `tra_inserted` datetime DEFAULT NULL,
  `tra_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `training_has_subject`
--

CREATE TABLE `training_has_subject` (
  `tra_id` int(10) UNSIGNED NOT NULL,
  `sub_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`cit_id`),
  ADD KEY `city_FKIndex1` (`cou_id`);

--
-- Index pour la table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`cou_id`);

--
-- Index pour la table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`ins_id`);

--
-- Index pour la table `marital_status`
--
ALTER TABLE `marital_status`
  ADD PRIMARY KEY (`mar_id`);

--
-- Index pour la table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`ses_id`),
  ADD KEY `session_FKIndex2` (`tra_id`);

--
-- Index pour la table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stu_id`),
  ADD UNIQUE KEY `stu_email` (`stu_email`),
  ADD KEY `student_FKIndex1` (`ses_id`),
  ADD KEY `student_FKIndex2` (`cou_id`),
  ADD KEY `student_FKIndex3` (`cit_id`),
  ADD KEY `student_FKIndex4` (`mar_id`);

--
-- Index pour la table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- Index pour la table `training`
--
ALTER TABLE `training`
  ADD PRIMARY KEY (`tra_id`);

--
-- Index pour la table `training_has_subject`
--
ALTER TABLE `training_has_subject`
  ADD PRIMARY KEY (`tra_id`,`sub_id`),
  ADD KEY `training_has_subject_FKIndex1` (`tra_id`),
  ADD KEY `training_has_subject_FKIndex2` (`sub_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `city`
--
ALTER TABLE `city`
  MODIFY `cit_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `country`
--
ALTER TABLE `country`
  MODIFY `cou_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `instructor`
--
ALTER TABLE `instructor`
  MODIFY `ins_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `marital_status`
--
ALTER TABLE `marital_status`
  MODIFY `mar_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `session`
--
ALTER TABLE `session`
  MODIFY `ses_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `student`
--
ALTER TABLE `student`
  MODIFY `stu_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT pour la table `subject`
--
ALTER TABLE `subject`
  MODIFY `sub_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `training`
--
ALTER TABLE `training`
  MODIFY `tra_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
