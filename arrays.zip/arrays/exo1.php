<?php

$mobileFirms = array(
	'Samsung',
	'Apple',
	'Wiko',
	'Windows',
	'LG',
	'Nokia',
	'Sony'
);
$windowsMobiles = array(3, 5);
$iosMobiles = array(1);
$androidMobiles = array(0, 2, 4, 6);

/* EXERCICE 1
- gr�ce � une boucle, afficher tous les "mobileFirm" sous iOS
- gr�ce � une boucle, afficher tous les "mobileFirm" sous windowsPhone
- gr�ce � une boucle, afficher tous les "mobileFirm" sous Android
(il existe 2 fa�ons de faire ces exos (avec ou sans "if"), une seule est demand�e)
=> ioS : Apple
windowsPhone : Windows Nokia
android : Samsung Wiko LG Sony
*/