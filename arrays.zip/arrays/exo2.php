<html>
<head>
	<title>EXERCICE 2</title>
</head>
<body>
	<pre>
<?php

// Je r�cup�re les tableaux de l'exercice 1
require 'exo1.php';

// J'initialise le tableau que vous aurez � remplir
$exo2Array = array();

/* EXERCICE 2
- lire les foreach sur cette page pour comprendre la structure demand�e pour le tableau $exo2Array
- indice : 2 foreach = ??? dimension(s)
- ne pas h�siter � faire un sch�ma du tableau si besoin
- vous ne pouvez coder qu'entre les 2 commentaires ci-dessous (pas de modification sur ce fichier en dehors de cette zone)
- parcourir le(s) tableau(x) de l'exo1 pour remplir le tableau $exo2Array
*/
// COMMENCEZ VOTRE CODE ICI

// Votre code ici...

// FINIR VOTRE CODE ICI
?>
<?php if (isset($exo2Array) && sizeof($exo2Array) > 0) : ?>
	<?php foreach ($exo2Array as $currentOS=>$currentOsFirms) : ?>
		<h3><?= $currentOS ?></h3>
		<ul>
		<?php foreach ($currentOsFirms as $currentFirm) : ?>
			<li><?= $currentFirm ?></li>
		<?php endforeach; ?>
		</ul>
	<?php endforeach; ?>
<?php endif; ?>
	</pre>
</body>
</html>