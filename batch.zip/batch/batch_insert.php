<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
		<title>New students</title>
	</head>
	<body>
		<pre>
			<?php
			require 'students_session2.php';
			require '../inc/db.php';

			//Première requette récupère les mail existants
			$sql_1='
				SELECT stu_email
				FROM student
			';

			//Création d'un tableau contenant les mails de SQL_1
			$emailList_1 = array();

			//Stocker les emails dans mon tableau
			$pdoStatement_1 = $pdo->query($sql_1);
			$emailList_1 = $pdoStatement_1 ->fetchAll();
			// print_r($emailList_1);

			//Créer un deuxième tableau simplifié qui stocke grace à une boucle les emails du premier tableau
			$emailList_2 = array();

			// Boucle pour stocker les mails du premier tableau vers le deuxieme tableau
			for ($i=0; $i < sizeof($emailList_1); $i++) { 
				$emailList_2[$i]=$emailList_1[$i][0];
			}
			// print_r($emailList_2)

			//Deuxème requette SQL pour insérer de nouvelles données (ne pas oublier de renseigner le SES_ID!!)
			$sql_2 = '
				INSERT INTO student (ses_id, stu_name, stu_firstname, stu_email, stu_birthdate, stu_sex, stu_with_experience, stu_is_leader)
				VALUES (:session, :name, :firstname, :email, :birthdate, :sex, :with_experience, :is_leader)
			';

			//Boucle FOR pour renseigner le nom des variables
			for ($j=0; $j < sizeof($studentsList); $j++) { 
				$name = $studentsList[$j]['name'];
				$firstname = $studentsList[$j]['firstname'];
				$email = $studentsList[$j]['email'];
				$birthdate = $studentsList[$j]['birthdate'];
				$sex = $studentsList[$j]['sex'];
				$with_experience = $studentsList[$j]['with_experience'];
				$is_leader = $studentsList[$j]['is_leader'];

				//initialisation de la variable à TRUE
				$newStudent = true;

				//vérification que les email existent dans mon tableau stocké avec la fonction IN_ARRAY
				if (in_array($studentsList[$j]['email'], $emailList_2)) {
					 
					//Dans le cas de l'email existant, la variable devient false donc pas de requette
					$newStudent = false;
				}

				//Si l'email n'existe pas, on fait la requette dans une boucle
				if ($newStudent == true) {
					$pdoStatement_2 = $pdo->prepare($sql_2);
					$pdoStatement_2->bindValue(':name',$name);
					$pdoStatement_2->bindValue(':firstname',$firstname);
					$pdoStatement_2->bindValue(':email',$email);
					$pdoStatement_2->bindValue(':birthdate',$birthdate);
					$pdoStatement_2->bindValue(':sex',$sex);
					$pdoStatement_2->bindValue(':with_experience',$with_experience, PDO::PARAM_INT);
					$pdoStatement_2->bindValue(':is_leader',$is_leader, PDO::PARAM_INT);
					$pdoStatement_2->bindValue(':session',2, PDO::PARAM_INT);
					$pdoStatement_2->execute();
				}

			}

			?>
		</pre>
	</body>
</html>