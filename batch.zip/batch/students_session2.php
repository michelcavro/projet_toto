<?php
$studentsList = array(
	array(
		'name' => 'CAVRO',
		'firstname' => 'Michel',
		'birthdate' => '2010-01-01',
		'email' => 'michel.cavro@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 1
	),
	array(
		'name' => 'BARDHI',
		'firstname' => 'Florian',
		'birthdate' => '1988-02-02',
		'email' => 'flo@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'CARNEIRO',
		'firstname' => 'Adelino',
		'birthdate' => '1975-10-01',
		'email' => 'adelino@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'COELHO',
		'firstname' => 'Patrick',
		'birthdate' => '1980-03-01',
		'email' => 'pat@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'DESWARTE',
		'firstname' => 'fabrice',
		'birthdate' => 'fabrice.',
		'email' => 'fab@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'FABRI',
		'firstname' => 'Paul',
		'birthdate' => '2001-02-05',
		'email' => 'polof@toto.fr',
		'sex' => 'M',
		'with_experience' => 1,
		'is_leader' => 0
	),
	array(
		'name' => 'IOANID',
		'firstname' => 'Paul',
		'birthdate' => '1968-02-08',
		'email' => 'poloi@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'LABIDI',
		'firstname' => 'Mondher',
		'birthdate' => '1980-12-04',
		'email' => 'apolearn@labidi.lu',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'RAIMUNDO',
		'firstname' => 'Claudio',
		'birthdate' => '1975-01-23',
		'email' => 'claudio@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'REUTER',
		'firstname' => 'Marc',
		'birthdate' => '1980-02-08',
		'email' => 'marc@reuters.com',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'ROLLAND',
		'firstname' => 'Marie',
		'birthdate' => '1980-07-22',
		'email' => 'marie.rolland@toto.fr',
		'sex' => 'F',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'SAMPAIO',
		'firstname' => 'Gabriela',
		'birthdate' => '1980-08-09',
		'email' => 'gabriela@toto.fr',
		'sex' => 'F',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'SCHMUTZ',
		'firstname' => 'Anne',
		'birthdate' => '1976-05-08',
		'email' => 'anne.truc@toto.fr',
		'sex' => 'F',
		'with_experience' => 1,
		'is_leader' => 0
	),
	array(
		'name' => 'TASCH',
		'firstname' => 'Philippe',
		'birthdate' => '2015-04-01',
		'email' => 'fifi@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'THIELLO',
		'firstname' => 'Ibrahima',
		'birthdate' => '1984-06-05',
		'email' => 'ibrahima@toto.fr',
		'sex' => 'M',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'VICENTE',
		'firstname' => 'Demetrio',
		'birthdate' => '1974-05-06',
		'email' => 'demetrio@toto.fr',
		'sex' => 'M',
		'with_experience' => 1,
		'is_leader' => 0
	),
	array(
		'name' => 'WAGEMANS',
		'firstname' => 'Charlotte',
		'birthdate' => '1984-09-07',
		'email' => 'chacha@toto.fr',
		'sex' => 'F',
		'with_experience' => 0,
		'is_leader' => 0
	),
	array(
		'name' => 'YIM',
		'firstname' => 'Anne-Marie',
		'birthdate' => '1980-06-08',
		'email' => 'annemarie@toto.fr',
		'sex' => 'F',
		'with_experience' => 0,
		'is_leader' => 0
	)
);